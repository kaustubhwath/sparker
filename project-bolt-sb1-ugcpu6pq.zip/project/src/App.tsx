import { useEffect, useState } from 'react';
import Navbar, { type Page } from '@/components/Navbar';
import Hero from '@/components/Hero';
import ProductsSection from '@/components/ProductsSection';
import GallerySection from '@/components/GallerySection';
import CatalogueSection from '@/components/CatalogueSection';
import PriceListSection from '@/components/PriceListSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import { business } from '@/data';

function App() {
  const [page, setPage] = useState<Page>('home');

  useEffect(() => {
    document.title = `${business.name} | Premium Fireworks`;
  }, []);

  return (
    <div className="min-h-screen bg-[#fff8ec]">
      <Navbar page={page} setPage={setPage} />
      {page === 'home' && (
        <>
          <Hero setPage={setPage} />
          <ProductsSection setPage={setPage} />
          <GallerySection />
          <CatalogueSection />
          <PriceListSection />
          <ContactSection />
        </>
      )}
      {page === 'products' && <ProductsSection setPage={setPage} />}
      {page === 'gallery' && <GallerySection />}
      {page === 'catalogue' && <CatalogueSection />}
      {page === 'pricelist' && <PriceListSection />}
      {page === 'contact' && <ContactSection />}
      <Footer setPage={setPage} />
    </div>
  );
}

export default App;
