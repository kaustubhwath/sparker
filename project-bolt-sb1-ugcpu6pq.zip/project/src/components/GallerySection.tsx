import { useState } from 'react';
import { X, Maximize2 } from 'lucide-react';
import { galleryImages } from '@/data';
import { useReveal } from '@/hooks/useReveal';

export default function GallerySection() {
  const reveal = useReveal<HTMLElement>();
  const [selected, setSelected] = useState<number | null>(null);
  return (
    <section ref={reveal.ref} className={`bg-red-950 px-4 py-20 sm:px-6 lg:py-28 ${reveal.visible ? 'reveal visible' : 'reveal'}`}>
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center"><p className="mb-2 text-sm font-bold uppercase tracking-[0.25em] text-amber-300">Moments of magic</p><h2 className="font-display text-4xl font-bold text-white sm:text-5xl">Our festive gallery</h2><p className="mx-auto mt-3 max-w-xl text-amber-100/70">A glimpse of the colour, light and celebration that makes every Diwali unforgettable.</p></div>
        <div className="columns-1 gap-5 sm:columns-2 lg:columns-4">
          {galleryImages.map((image, index) => <button key={image.url} onClick={() => setSelected(index)} className="group relative mb-5 block w-full overflow-hidden rounded-xl text-left"><img src={image.url} alt={image.caption} className={`w-full object-cover transition duration-700 group-hover:scale-105 ${index % 3 === 0 ? 'aspect-[4/5]' : 'aspect-[4/3]'}`} /><div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent opacity-0 transition group-hover:opacity-100" /><span className="absolute bottom-4 left-4 translate-y-3 text-sm font-semibold text-white opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">{image.caption}</span><span className="absolute right-3 top-3 rounded-full bg-white/15 p-2 text-white opacity-0 backdrop-blur-sm transition group-hover:opacity-100"><Maximize2 className="h-4 w-4" /></span></button>)}
        </div>
      </div>
      {selected !== null && <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 p-4" onClick={() => setSelected(null)}><button onClick={() => setSelected(null)} className="absolute right-5 top-5 rounded-full bg-white/10 p-3 text-white" aria-label="Close gallery"><X className="h-6 w-6" /></button><img src={galleryImages[selected].url} alt={galleryImages[selected].caption} className="max-h-[85vh] max-w-full rounded-lg object-contain" /></div>}
    </section>
  );
}
