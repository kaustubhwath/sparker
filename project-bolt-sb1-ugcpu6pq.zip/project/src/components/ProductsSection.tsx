import { ArrowRight, MessageCircle, ShoppingBag } from 'lucide-react';
import { products, business } from '@/data';
import { useReveal } from '@/hooks/useReveal';
import type { Page } from './Navbar';

export default function ProductsSection({ setPage }: { setPage: (page: Page) => void }) {
  const reveal = useReveal<HTMLElement>();
  const featured = products.slice(0, 8);
  return (
    <section ref={reveal.ref} className={`bg-[#fff8ec] px-4 py-20 sm:px-6 lg:py-28 ${reveal.visible ? 'reveal visible' : 'reveal'}`}>
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="mb-2 text-sm font-bold uppercase tracking-[0.25em] text-red-700">Our collection</p>
            <h2 className="font-display text-4xl font-bold text-red-950 sm:text-5xl">Light up every moment</h2>
            <p className="mt-3 max-w-xl text-slate-600">From a tiny sparkler to a sky full of colour, discover festive favourites selected for every celebration.</p>
          </div>
          <button onClick={() => setPage('products')} className="inline-flex items-center gap-2 self-start rounded-full border-2 border-red-800 px-5 py-2.5 text-sm font-bold uppercase tracking-wide text-red-800 transition hover:bg-red-800 hover:text-white sm:self-auto">View all products <ArrowRight className="h-4 w-4" /></button>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((product) => (
            <article key={product.id} className="card-lift group overflow-hidden rounded-2xl border border-amber-900/10 bg-white shadow-md">
              <div className="relative h-52 overflow-hidden bg-red-950">
                <img src={product.image} alt={product.name} className="h-full w-full object-cover opacity-85 transition duration-700 group-hover:scale-110 group-hover:opacity-100" />
                <div className="absolute inset-0 bg-gradient-to-t from-red-950/80 via-transparent to-transparent" />
                <span className="absolute left-3 top-3 rounded-full bg-amber-400 px-3 py-1 text-[10px] font-bold uppercase tracking-wide text-red-950">{product.category}</span>
                <span className="absolute bottom-3 left-4 font-display text-2xl font-bold text-white">{product.price}</span>
              </div>
              <div className="p-5">
                <p className="font-display text-xl font-bold text-red-950">{product.name}</p>
                <p className="mt-1 text-xs font-medium uppercase tracking-widest text-amber-700">{product.hindi} · {product.unit}</p>
                <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-600">{product.description}</p>
                <a href={`https://wa.me/${business.whatsapp}?text=${encodeURIComponent(`Hello, I would like to order ${product.name}.`)}`} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-red-800 transition hover:text-amber-700"><MessageCircle className="h-4 w-4" /> Enquire now</a>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-5 rounded-2xl bg-festive px-6 py-6 text-center sm:flex-row sm:text-left">
          <div className="flex items-center gap-4"><ShoppingBag className="hidden h-10 w-10 text-amber-300 sm:block" /><div><p className="font-display text-xl font-bold text-white">Planning a big celebration?</p><p className="text-sm text-amber-100/80">Explore our family and premium combo packs.</p></div></div>
          <button onClick={() => setPage('catalogue')} className="rounded-full bg-amber-400 px-5 py-2.5 text-sm font-bold text-red-950 transition hover:bg-amber-300">See combo packs</button>
        </div>
      </div>
    </section>
  );
}
