import { ArrowRight, Check, MessageCircle, Sparkles } from 'lucide-react';
import { business } from '@/data';
import type { Page } from './Navbar';

export default function Hero({ setPage }: { setPage: (page: Page) => void }) {
  return (
    <section className="relative min-h-[680px] overflow-hidden bg-festive-deep sparkle-bg">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_40%,rgba(193,18,31,0.55),transparent_38%),linear-gradient(90deg,rgba(42,0,0,0.95),rgba(74,0,0,0.55),rgba(42,0,0,0.7))]" />
      <div className="absolute right-[-8%] top-[10%] h-[520px] w-[520px] rounded-full border border-amber-400/20 sm:h-[700px] sm:w-[700px]" />
      <div className="absolute right-[4%] top-[23%] h-[340px] w-[340px] rounded-full border border-amber-400/20 sm:h-[480px] sm:w-[480px]" />
      <div className="absolute right-[18%] top-[34%] h-2 w-2 rounded-full bg-amber-300 shadow-[0_0_24px_10px_rgba(245,197,66,0.7)] animate-pulse" />
      <div className="absolute bottom-8 left-[12%] h-1.5 w-1.5 rounded-full bg-amber-300 shadow-[0_0_20px_8px_rgba(245,197,66,0.6)] animate-pulse" />

      <div className="relative mx-auto flex min-h-[680px] max-w-7xl items-center px-4 py-20 sm:px-6 lg:py-24">
        <div className="max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-300">
            <Sparkles className="h-4 w-4" /> Trusted since 1998
          </div>
          <p className="mb-3 font-display text-lg font-semibold tracking-[0.3em] text-amber-300 sm:text-xl">LIGHT UP YOUR CELEBRATIONS</p>
          <h2 className="font-display text-5xl font-black uppercase leading-[1.05] tracking-tight text-white sm:text-7xl lg:text-8xl">
            Every Spark
            <span className="block text-gradient-gold">Tells a Story</span>
          </h2>
          <p className="mt-6 max-w-xl text-base leading-7 text-amber-100/80 sm:text-lg">
            Premium fireworks, joyful memories and the magic of Diwali — all under one roof at {business.name}.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <button onClick={() => setPage('products')} className="btn-gold inline-flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-bold uppercase tracking-wide text-red-950 shadow-lg transition hover:scale-105">
              Explore Products <ArrowRight className="h-4 w-4" />
            </button>
            <a href={`https://wa.me/${business.whatsapp}?text=${encodeURIComponent('Hello, I would like to see the Paramatma Ek Fataka Bhandar catalogue.')}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-amber-300/50 bg-white/5 px-6 py-3.5 text-sm font-bold uppercase tracking-wide text-amber-100 transition hover:border-amber-300 hover:bg-amber-300/10">
              <MessageCircle className="h-4 w-4" /> Order on WhatsApp
            </a>
          </div>
          <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-amber-100/80">
            {['Licensed fireworks', 'Premium quality', 'Fast delivery'].map((item) => (
              <span key={item} className="flex items-center gap-2"><Check className="h-4 w-4 text-amber-300" />{item}</span>
            ))}
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#fff8ec] to-transparent" />
    </section>
  );
}
