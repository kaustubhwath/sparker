import { Flame } from 'lucide-react';

export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-red-700 shadow-lg ring-2 ring-amber-300/50">
          <Flame className="h-6 w-6 text-white drop-shadow" strokeWidth={2.2} />
        </div>
        <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-amber-300 animate-pulse" />
      </div>
      {!compact && (
        <div className="leading-tight">
          <h1 className="font-display text-base font-bold tracking-wide text-amber-300 sm:text-lg">
            PARAMATMA
          </h1>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-100/80">
            Ek Fataka Bhandar
          </p>
        </div>
      )}
    </div>
  );
}
