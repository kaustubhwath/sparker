import { useEffect, useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import Logo from './Logo';
import { business } from '@/data';

export type Page = 'home' | 'products' | 'gallery' | 'catalogue' | 'pricelist' | 'contact';

const navItems: { id: Page; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'products', label: 'Products' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'catalogue', label: 'Catalogue' },
  { id: 'pricelist', label: 'Price List' },
  { id: 'contact', label: 'Contact' },
];

export default function Navbar({ page, setPage }: { page: Page; setPage: (p: Page) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (p: Page) => {
    setPage(p);
    setOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Top announcement bar */}
      <div className="bg-festive-deep text-amber-100 text-xs sm:text-sm overflow-hidden border-b border-amber-500/30">
        <div className="flex whitespace-nowrap animate-marquee py-1.5">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex items-center gap-8 px-4">
              <span>✦ Diwali Special Offer — Up to 40% OFF on Combo Packs</span>
              <span>✦ Free Delivery on orders above ₹2000</span>
              <span>✦ 100% Safe &amp; Licensed Fireworks</span>
              <span>✦ Call Now: {business.phone}</span>
              <span>✦ Diwali Special Offer — Up to 40% OFF on Combo Packs</span>
              <span>✦ Free Delivery on orders above ₹2000</span>
              <span>✦ 100% Safe &amp; Licensed Fireworks</span>
              <span>✦ Call Now: {business.phone}</span>
            </div>
          ))}
        </div>
      </div>

      <header
        className={`sticky top-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-festive-deep/95 backdrop-blur-md shadow-xl shadow-black/30'
            : 'bg-festive'
        }`}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <button onClick={() => go('home')} className="flex items-center">
            <Logo />
          </button>

          {/* Desktop nav */}
          <ul className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => go(item.id)}
                  className={`relative px-4 py-2 text-sm font-medium uppercase tracking-wide transition-colors ${
                    page === item.id
                      ? 'text-amber-300'
                      : 'text-amber-100/90 hover:text-amber-300'
                  }`}
                >
                  {item.label}
                  {page === item.id && (
                    <span className="absolute bottom-0 left-1/2 h-0.5 w-6 -translate-x-1/2 rounded-full bg-amber-400" />
                  )}
                </button>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <a
              href={`tel:${business.phone.replace(/\s/g, '')}`}
              className="hidden items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-2 text-sm font-semibold text-amber-200 transition hover:bg-amber-400/20 sm:flex"
            >
              <Phone className="h-4 w-4" />
              Call Now
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="rounded-md p-2 text-amber-200 lg:hidden"
              aria-label="Toggle menu"
            >
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        <div
          className={`overflow-hidden transition-all duration-300 lg:hidden ${
            open ? 'max-h-96' : 'max-h-0'
          }`}
        >
          <ul className="space-y-1 bg-festive-deep px-4 pb-4 pt-2">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => go(item.id)}
                  className={`block w-full rounded-lg px-4 py-3 text-left text-sm font-medium uppercase tracking-wide transition ${
                    page === item.id
                      ? 'bg-amber-400/20 text-amber-300'
                      : 'text-amber-100/90 hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              </li>
            ))}
            <li>
              <a
                href={`tel:${business.phone.replace(/\s/g, '')}`}
                className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-amber-400 px-4 py-3 text-sm font-bold text-red-900"
              >
                <Phone className="h-4 w-4" /> {business.phone}
              </a>
            </li>
          </ul>
        </div>
      </header>
    </>
  );
}
