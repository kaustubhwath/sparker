export type Product = {
  id: string;
  name: string;
  hindi: string;
  category: string;
  price: string;
  unit: string;
  image: string;
  description: string;
};

export type PriceItem = {
  id: string;
  name: string;
  hindi: string;
  category: string;
  unit: string;
  price: number;
};

export const categories = [
  'All',
  'Flower Pots',
  'Sparklers',
  'Ground',
  'Aerial',
  'Bombs',
  'Fancy',
  'Kids',
  'Colour Smoke',
  'Combo Packs',
];

export const products: Product[] = [
  {
    id: 'p1',
    name: 'Flower Pots (Anar)',
    hindi: 'अनार',
    category: 'Flower Pots',
    price: '₹120 – ₹250',
    unit: 'per box',
    image: 'https://images.pexels.com/photos/34396178/pexels-photo-34396178.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Classic ground fountains spraying golden sparks 10-15 feet high. A Diwali staple for every home.',
  },
  {
    id: 'p2',
    name: 'Sparklers (Phuljhadi)',
    hindi: 'फुलझड़ी',
    category: 'Sparklers',
    price: '₹50',
    unit: '10 pcs',
    image: 'https://images.pexels.com/photos/34416999/pexels-photo-34416999.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Hand-held sparkling sticks that light up the night. Safe and loved by all ages.',
  },
  {
    id: 'p3',
    name: 'Chakri',
    hindi: 'चकरी',
    category: 'Ground',
    price: '₹100',
    unit: 'per pack',
    image: 'https://images.pexels.com/photos/6358545/pexels-photo-6358545.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Spinning ground wheels that rotate with colourful sparks. A garden favourite.',
  },
  {
    id: 'p4',
    name: 'Rockets',
    hindi: 'रॉकेट',
    category: 'Aerial',
    price: '₹150',
    unit: 'per pack',
    image: 'https://images.pexels.com/photos/3656267/pexels-photo-3656267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Whistling rockets that shoot high and burst into a colourful star shower.',
  },
  {
    id: 'p5',
    name: 'Sky Shots',
    hindi: 'स्काई शॉट',
    category: 'Aerial',
    price: '₹400',
    unit: 'per box',
    image: 'https://images.pexels.com/photos/1503520/pexels-photo-1503520.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Multi-shot aerial repeaters launching a sequence of sky bursts. Show-stopping display.',
  },
  {
    id: 'p6',
    name: 'Laxmi Bomb',
    hindi: 'लक्ष्मी बम',
    category: 'Bombs',
    price: '₹200',
    unit: 'per box',
    image: 'https://images.pexels.com/photos/6240/6240-fireworks-new-year-sky.jpg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Classic loud cracker box with a powerful bang. The traditional Diwali sound.',
  },
  {
    id: 'p7',
    name: 'Atom Bomb',
    hindi: 'एटम बम',
    category: 'Bombs',
    price: '₹300',
    unit: 'per box',
    image: 'https://images.pexels.com/photos/6942352/pexels-photo-6942352.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Extra-loud single-shot bomb with a thunderous boom. For the bold cracker lover.',
  },
  {
    id: 'p8',
    name: 'Fancy Fountain',
    hindi: 'फैंसी फाउंटेन',
    category: 'Fancy',
    price: '₹500',
    unit: 'per piece',
    image: 'https://images.pexels.com/photos/1580088/pexels-photo-1580088.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Long-duration colourful fountain with crackling stars and changing colours.',
  },
  {
    id: 'p9',
    name: 'Kids Crackers',
    hindi: 'किड्स क्रैकर्स',
    category: 'Kids',
    price: '₹999',
    unit: 'combo pack',
    image: 'https://images.pexels.com/photos/15143047/pexels-photo-15143047.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'A safe, low-noise assortment of sparklers, pop-pops and ground items for children.',
  },
  {
    id: 'p10',
    name: 'Colour Smoke',
    hindi: 'कलर स्मोक',
    category: 'Colour Smoke',
    price: '₹350',
    unit: 'per pack',
    image: 'https://images.pexels.com/photos/12755184/pexels-photo-12755184.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Vibrant coloured smoke candles in red, green, blue and orange. Great for photoshoots.',
  },
  {
    id: 'p11',
    name: 'Diwali Family Combo',
    hindi: 'परिवार कॉम्बो',
    category: 'Combo Packs',
    price: '₹1999',
    unit: 'mega pack',
    image: 'https://images.pexels.com/photos/19212789/pexels-photo-19212789.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'A complete family assortment — flower pots, sparklers, chakri, rockets and fancy items.',
  },
  {
    id: 'p12',
    name: 'Premium Combo',
    hindi: 'प्रीमियम कॉम्बो',
    category: 'Combo Packs',
    price: '₹4999',
    unit: 'grand pack',
    image: 'https://images.pexels.com/photos/29556501/pexels-photo-29556501.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    description: 'Our grandest collection — sky shots, aerial bursts, fancy fountains and full family assortment.',
  },
];

export const priceList: PriceItem[] = [
  { id: 'pr1', name: 'Phuljhadi', hindi: 'फुलझड़ी', category: 'Sparklers', unit: '10 pcs', price: 50 },
  { id: 'pr2', name: 'Flower Pot Small', hindi: 'अनार छोटा', category: 'Flower Pots', unit: 'per box', price: 120 },
  { id: 'pr3', name: 'Flower Pot Big', hindi: 'अनार बड़ा', category: 'Flower Pots', unit: 'per box', price: 250 },
  { id: 'pr4', name: 'Chakri Pack', hindi: 'चकरी', category: 'Ground', unit: 'per pack', price: 100 },
  { id: 'pr5', name: 'Rocket Pack', hindi: 'रॉकेट', category: 'Aerial', unit: 'per pack', price: 150 },
  { id: 'pr6', name: 'Sky Shot', hindi: 'स्काई शॉट', category: 'Aerial', unit: 'per box', price: 400 },
  { id: 'pr7', name: 'Laxmi Bomb Box', hindi: 'लक्ष्मी बम', category: 'Bombs', unit: 'per box', price: 200 },
  { id: 'pr8', name: 'Atom Bomb Box', hindi: 'एटम बम', category: 'Bombs', unit: 'per box', price: 300 },
  { id: 'pr9', name: 'Fancy Fountain', hindi: 'फैंसी फाउंटेन', category: 'Fancy', unit: 'per piece', price: 500 },
  { id: 'pr10', name: 'Colour Smoke', hindi: 'कलर स्मोक', category: 'Colour Smoke', unit: 'per pack', price: 350 },
  { id: 'pr11', name: 'Kids Combo', hindi: 'किड्स कॉम्बो', category: 'Combo Packs', unit: 'combo pack', price: 999 },
  { id: 'pr12', name: 'Family Combo', hindi: 'परिवार कॉम्बो', category: 'Combo Packs', unit: 'mega pack', price: 1999 },
  { id: 'pr13', name: 'Premium Combo', hindi: 'प्रीमियम कॉम्बो', category: 'Combo Packs', unit: 'grand pack', price: 4999 },
];

export const galleryImages = [
  { url: 'https://images.pexels.com/photos/34396178/pexels-photo-34396178.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Diwali Night Sky' },
  { url: 'https://images.pexels.com/photos/19212789/pexels-photo-19212789.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Grand Celebration' },
  { url: 'https://images.pexels.com/photos/1580088/pexels-photo-1580088.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Fountain Display' },
  { url: 'https://images.pexels.com/photos/6054332/pexels-photo-6054332.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Diwali in India' },
  { url: 'https://images.pexels.com/photos/3656267/pexels-photo-3656267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Sky Burst' },
  { url: 'https://images.pexels.com/photos/15143047/pexels-photo-15143047.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Sparkler Joy' },
  { url: 'https://images.pexels.com/photos/29556501/pexels-photo-29556501.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Festive Lights' },
  { url: 'https://images.pexels.com/photos/1503520/pexels-photo-1503520.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Colour Splash' },
  { url: 'https://images.pexels.com/photos/6358545/pexels-photo-6358545.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Red Spark' },
  { url: 'https://images.pexels.com/photos/12755184/pexels-photo-12755184.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Night Celebration' },
  { url: 'https://images.pexels.com/photos/14363699/pexels-photo-14363699.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Sparkler Night' },
  { url: 'https://images.pexels.com/photos/8621919/pexels-photo-8621919.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', caption: 'Light Trails' },
];

export const business = {
  name: 'PARAMATMA EK FATAKA BHANDAR',
  tagline: 'The Spirit of Diwali, In Every Spark',
  phone: '+91 98765 43210',
  whatsapp: '919876543210',
  email: 'paramatma.fataka@gmail.com',
  address: 'Main Road, Diwali Bazaar, Sivakasi, Tamil Nadu 626123',
  hours: 'Mon – Sun: 9:00 AM – 9:00 PM',
  established: 'Since 1998',
};
